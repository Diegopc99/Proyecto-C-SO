

int main(){

	int a = 0;
	int b = 0;

	for(a=0;a<2800000000;a++){

	b=a;

	}

return 1;

}
